global.API_KEY = 'api-backend-devninjas';
